<p><b>This iframe is located on <span id="domain"> </span>.</p>
 
<div id="msg"> </div>
 
<form id="form">
    <input type="text" id="msg" placeholder="Type message to send"/>
    <input id="send_msg" type="button" value="Send message to parent page" />
</form>